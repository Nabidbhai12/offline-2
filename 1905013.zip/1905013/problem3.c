#include<stdio.h>
int main()
{
    int arr[100000];
    int n,max=-1;
    scanf("%d",&n);
    for(int a=0;a<n;a++){
        scanf("%d",&arr[a]);
        if(arr[a]>max)
            max=arr[a];
    }
    for(int b=max;b>0;b--)
    {
        for(int c=0;c<n;c++)
        {
            if(arr[c]>=b)
            {
                printf("**");
            }
            else
            {
                printf("  ");
            }
            printf(" ");
        }
        printf("\n");
    }
}
