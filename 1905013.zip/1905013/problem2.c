#include<stdio.h>
int perfectnumber(long long int num)
{
    if(num==1)
        return 0;
    long long int sum=0;
    for(int a=2;a*a<=num;a++)
    {
        if(num%a==0)
        {

            sum+=a;
            if(num/a !=a)
                sum+=(num/a);
        }



    }
    return (sum+1)==num;
}
int main()
{
    long long int n,t=1,count=0;
    scanf("%lld",&n);
    while(t<=n)
    {
        if(perfectnumber(t))
            count+=t;
        t++;
    }
    printf("%lld\n",count);

}
