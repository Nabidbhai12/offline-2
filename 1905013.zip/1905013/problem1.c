#include<stdio.h>
#define MAX 20000
void f1(int arr[])
{
    int max=arr[0],idx=0;
    for(int a=1;a<=MAX;a++)
    {
        if(arr[a]>max)
        {
            max=arr[a];
            idx=a;
        }

    }
    if(idx>10000)
    printf("Most frequent number = %d",-(idx-10000));
    else
        printf("Most frequent number = %d",idx);
    for(int b=0;b<=MAX;b++)
    {
        if(max==arr[b] && b!=idx)
        {
            if(b>10000)
            {

                printf(", %d ",-(b-10000));

            }
            else
            {
                printf(", %d ",b);

            }
        }
    }
  //  printf("\b\b ");
    printf("\n");
}
int main()
{
    int arr[MAX+1]={0};
    int n,num;
    scanf("%d",&n);
    for(int a=0;a<n;a++)
    {
        scanf("%d",&num);
        if(num>=0)
        {
            arr[num]+=1;
        }
        else
        {
            num=num*-1;
            num+=10000;
            arr[num]+=1;

        }
        f1(arr);
    }
}
